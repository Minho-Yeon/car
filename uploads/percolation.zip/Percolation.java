
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private boolean[][] id;
    // private int id2;

    private final WeightedQuickUnionUF wuf;
    private final WeightedQuickUnionUF wuf2;

    private int numberopen;
    private int top;
    // private int[] bottom;
    private int bottom;
    private int num;
    // private boolean[][] isf, isf2;

    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Given N <= 0");
        }
        numberopen = 0;
        id = new boolean[n][n];
        // isf = new boolean[n][n];
        // isf2 = new boolean[n][n];
        wuf = new WeightedQuickUnionUF(n * n + 2);

        // id2 = new int[n];
        wuf2 = new WeightedQuickUnionUF(n * n + 1);
        top = n * n;
        bottom = n * n + 1;
        // bottom = new int[n];
        num = 0;
    }               // 모든 사이트가 차단 된 상태에서 nx 째 그리드를 만듭니다.

    private void check(int row, int col) {
        if (row < 1 || row > id.length || col < 1 || col > id.length) {
            throw new IllegalArgumentException("Given N <= 0");
        }

    }

    public void open(int row, int col) {
        check(row, col);
        if (isOpen(row, col)) {
            return;
        }
        row -= 1;
        col -= 1;


        id[row][col] = true;
        numberopen++;
        if (row == 0) {
            wuf.union(top, row * id.length + col);
            // wuf2.union(top, row * id.length + col);
        }
        if (row == id.length - 1) {
            // bottom = wuf.find(bottom);
            // if (num == 0) {
            //     bottom[num] = wuf.find(row * id.length + col);
            //     num++;
            // }
            // for (int i = 0; i < num; i++) {
            //     if (!wuf.connected(bottom[i], row * id.length + col)) {
            //
            //         bottom[num] = wuf.find(row * id.length + col);
            //         num++;
            //         break;
            //     }
            // }

            wuf.union(bottom, row * id.length + col);


        }
        if (row != 0 && isOpen(row, col + 1)) {
            wuf.union((row - 1) * id.length + col, row * id.length + col);
            // wuf2.union((row - 1) * id.length + col, row * id.length + col);
        }
        if (row != id.length - 1 && isOpen(row + 2, col + 1)) {
            wuf.union((row + 1) * id.length + col, row * id.length + col);
            // wuf2.union((row + 1) * id.length + col, row * id.length + col);
        }
        if (col != 0 && isOpen(row + 1, col)) {
            wuf.union(row * id.length + col - 1, row * id.length + col);
            // wuf2.union(row * id.length + col - 1, row * id.length + col);
        }
        if (col != id.length - 1 && isOpen(row + 1, col + 2)) {
            wuf.union(row * id.length + col + 1, row * id.length + col);
            // wuf2.union(row * id.length + col + 1, row * id.length + col);
        }
    }     // 열려 있지 않은 사이트 (행, 열)

    public boolean isOpen(int row, int col) {
        check(row, col);
        row -= 1;
        col -= 1;

        return id[row][col];
    } // 사이트 (행, 열)가 열려 있습니까?

    public boolean isFull(int row, int col) {
        check(row, col);
        row -= 1;
        col -= 1;
        // if (wuf.connected(row * id.length + col, bottom)) {
        //     if (col == 0) {
        //         if (true) {
        //             return false;
        //         }
        //     }
        //     else {
        //         if (wuf.connected(row * id.length + col, row * id.length + col - 1)) {
        //             return false;
        //         }
        //     }
        //     return false;
        // }
        // } row != 0 &&
        //         wuf.connected(row * id.length + col, (row - 1) * id.length + col) && col != 0 &&
        //         wuf.connected(row * id.length + col, row * id.length + col - 1)
        //         && col != id.length - 1 &&
        //         wuf.connected(row * id.length + col, row * id.length + col + 1)) {
        //     return false;
        // }


        // if (isf[row][col] != isf2[row][col]) {
        return wuf.connected(top, row * id.length + col);
        // }

    }  // 사이트 (행, 열)가 꽉 찼습니까?

    public int numberOfOpenSites() {


        return numberopen;
    }       // 열려있는 사이트의 수

    public boolean percolates() {

        // if (!wuf.connected(top, bottom)) {
        //     for (int i = 0; i < id.length * id.length; i++) {
        //         if (wuf.connected(i, top)) {
        //             isf[i / id.length][i % id.length] = true;
        //         }
        //         if (wuf.connected(i, bottom)) {
        //             isf2[i / id.length][i % id.length] = true;
        //         }
        //
        //     }
        // }
        // else {
        //     for (int i = 0; i < id.length * id.length; i++) {
        //         if (wuf.connected(i, top)) {
        //             isf2[i / id.length][i % id.length] = true;
        //         }
        //     }
        // }
        // for (int i = 0; i < bottom.length; i++) {
        //     if (wuf.connected(top, bottom[i])) {
        //
        //     }
        // }
        // for (int i = 0; i < num; i++) {
        //     if (wuf.connected(top, bottom[i])) {
        //         return true;
        //     }
        // }
        // return false;
        // wuf.connected(a, row * id.length + col);
        // return wuf.find(top) ==;
        return wuf.connected(top, bottom);
    }            // 시스템이 침투 하는가?


    public static void main(String[] args) {
        Percolation pc = new Percolation(Integer.parseInt(args[0]));
        while (!pc.percolates()) {
            int ran_row = StdRandom.uniform(1, pc.id.length + 1);
            int ran_col = StdRandom.uniform(1, pc.id.length + 1);

            if (!pc.isOpen(ran_row, ran_col)) {
                pc.open(ran_row, ran_col);
            }

        }

        for (int i = 0; i < pc.id.length; i++) {
            // for (int j = 0; j < pc.id.length; j++) {
            //     // StdOut.print(pc.id[i][j] + "\t");
            //     StdOut.print(pc.isFull(i + 1, j + 1) + "\t");
            // }
            // StdOut.print("\t\t");

            // for (int j = 0; j < pc.id.length; j++) {
            //     // StdOut.print(pc.id[i][j] + "\t");
            //     StdOut.print(pc.isf[i][j] + "\t");
            // }
            // StdOut.print("\t\t");
            // for (int j = 0; j < pc.id.length; j++) {
            //     // StdOut.print(pc.id[i][j] + "\t");
            //     StdOut.print(pc.isf2[i][j] + "\t");
            // }
            // StdOut.print("\t\t");
            for (int j = 0; j < pc.id.length; j++) {
                // StdOut.print(pc.id[i][j] + "\t");
                StdOut.print(pc.isFull(i + 1, j + 1) + "\t");
            }
            StdOut.print("\t\t");
            for (int j = 0; j < pc.id.length; j++) {
                StdOut.print(pc.wuf.find(pc.id.length * i + j) + "\t");
            }
            StdOut.println();

        }
        StdOut.println(pc.wuf.find(pc.top));
        // StdOut.println(pc.wuf.find(pc.bottom));

    }

}
