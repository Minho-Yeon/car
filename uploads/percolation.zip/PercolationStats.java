/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private final double[] x;
    private final int t;
    private double mean, stddev;

    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException("Given N <= 0 || T <= 0");
        }
        t = trials;
        x = new double[t];

        int a;
        int b;
        for (int i = 0; i < t; i++) {
            Percolation pc = new Percolation(n);
            while (!pc.percolates()) {
                a = StdRandom.uniform(1, n + 1);
                b = StdRandom.uniform(1, n + 1);
                if (!pc.isOpen(a, b)) {
                    pc.open(a, b);
                }
            }
            x[i] = (double) pc.numberOfOpenSites() / (n * n);
        }
        mean = StdStats.mean(x);
        stddev = StdStats.stddev(x);
    }   // perform trials independent experiments on an n-by-n grid

    public double mean() {
        return mean;
    }      // sample mean of percolation threshold

    public double stddev() {
        return stddev;
    }            // sample standard deviation of percolation threshold

    public double confidenceLo() {
        return mean() - (1.96 * stddev() / Math.sqrt(t));
    }       // low  endpoint of 95% confidence interval

    public double confidenceHi() {
        return mean() + (1.96 * stddev() / Math.sqrt(t));
    }        // high endpoint of 95% confidence interval

    public static void main(String[] args) {
        PercolationStats ps = new PercolationStats(Integer.parseInt(args[0]),
                                                   Integer.parseInt(args[1]));

        StdOut.println("mean                    = " + ps.mean());
        StdOut.println("steddev                 = " + ps.stddev());
        StdOut.println(
                "95% confidence interval = [" + ps.confidenceLo() + ", " + ps.confidenceHi()
                        + "]");
    }      // test client (described below)
}
